import React from 'react'

function Landlords() {
    return (
        <div>
            <p>Landlords</p>
        </div>
    )
}

export default Landlords
