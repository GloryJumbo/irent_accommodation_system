import React from "react";
import {Link} from "react-router-dom";

function NavbarComp() {
  return (
    <div className="navbar-css">
      <p>iRent Content Management System</p>
      <div class="btn-group" role="group" aria-label="Basic example">
       
        <button type="button" class="btn btn-secondary">
          Houses
          </button>
        <button type="button" class="btn btn-secondary">
        Rooms
          </button>
        <button type="button" class="btn btn-secondary">Landlords</button>
        <button type="button" class="btn btn-secondary">Bookings</button>
        <button type="button" class="btn btn-secondary">Phonenumbers</button>
        <button type="button" class="btn btn-secondary">Status</button>
      </div>
    </div>
  );
}

export default NavbarComp;
