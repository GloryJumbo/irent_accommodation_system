import './App.css';
import NavbarComp from './components/navbars/navbarComp';
import Houses from './components/views/Houses';
import {Route} from 'react-router';
import { BrowserRouter as Router, Routes } from 'react-router-dom';
import Landlords from './components/views/Landlords';

function App() {
  return (
    <div className="App">
      <NavbarComp />
      <Houses />
      <Router>
        <Routes>
          
            <Route path="/houses" element={<Houses />} />
            <Route path="/landlords" element={<Landlords />} />
          
        </Routes>
      </Router>
    </div>
  );
}

export default App;
